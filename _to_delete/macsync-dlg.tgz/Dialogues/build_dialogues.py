#!/usr/bin/env python3
"""Parse dialogues.md into per-story dialogue JSON, resolve verbMap against each
story's vocab, validate every marked verb and expression, and write dialogues.json."""
import json, re, sys, os

MD = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dialogues.md")
STORY_DIR = "/tmp/uitest/mirror/stories"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dialogues.json")

# Cards for n1-n4 (approved in chat; the md file stores only the expression lists).
EXTRA_CARDS = {
 "giraffes-math-barcelona-2026": [
  ("weird question","A question that sounds strange or unexpected",["Weird question, but do you like pineapple on pizza?"]),
  ("come on","Used to say you do not believe someone",["Come on, that can't be true."]),
  ("just got lucky","Succeeded by chance, not by skill",["I won, but honestly I just got lucky."]),
  ("that's what I said","Used when someone repeats your own opinion",["Too expensive, right? That's what I said!"]),
  ("what's next","Used as a joke about more surprising things coming",["Dogs driving cars? What's next?"]),
  ("honestly","Used to show you really mean what you say",["Honestly, I didn't enjoy the movie."]),
 ],
 "venezuela-earthquake-rescue-2026": [
  ("somehow","In a way that is hard to explain",["Somehow the cat opened the door by itself."]),
  ("I can't imagine","Used when something is too hard or painful to think about",["I can't imagine losing my phone for a week."]),
  ("me neither","Used to agree with a negative sentence",["I don't like horror movies. Me neither."]),
  ("wow","Used to show surprise",["Wow, that's an amazing photo."]),
  ("that's what everyone's saying","Used when many people share the same opinion",["The new cafe is great. That's what everyone's saying."]),
 ],
 "swift-kelce-wedding-charity-2026": [
  ("I know!","Used to agree strongly with someone",["This weather is perfect. I know!"]),
  ("apparently","Used when you heard something but are not fully sure",["Apparently the store closes early on Sundays."]),
  ("like it was her own","As if the thing belonged to her",["She cleaned my kitchen like it was her own."]),
  ("half of Hollywood","A way to exaggerate how many people were there",["Half of Hollywood showed up for the premiere.","It felt like half the city was at the concert."]),
  ("that's hard to beat","Used when something is almost impossible to do better",["Dinner on the beach? That's hard to beat."]),
  ("you know what","Used to introduce an opinion or new thought",["You know what surprised me? The price."]),
 ],
 "italy-solar-railway-2026": [
  ("here's something clever","Used to introduce a smart idea",["Here's something clever: the bottle becomes a lamp."]),
  ("they thought of that","The planners already found an answer to that problem",["What if it rains? Don't worry, they thought of that."]),
  ("smart","A short way to say an idea is intelligent",["You booked early? Smart."]),
  ("that's the hope","Used to say people want it to happen but are not sure",["Will it be ready by May? That's the hope."]),
  ("classic","A funny way to say something always happens this way",["The bus left one minute early. Classic."]),
 ],
}

IRR = {
 "found":"find","carried":"carry","took":"take","taken":"take","came":"come","went":"go",
 "gone":"go","goes":"go","brought":"bring","held":"hold","dug":"dig","gave":"give","given":"give",
 "paid":"pay","pays":"pay","got":"get","gotten":"get","stood":"stand","stuck":"stick","wound":"wind",
 "fell":"fall","fallen":"fall","flew":"fly","flown":"fly","spoke":"speak","spoken":"speak",
 "sent":"send","laid":"lay","lays":"lay","ran":"run","threw":"throw","thrown":"throw",
 "caught":"catch","built":"build","shot":"shoot","dealt":"deal","swept":"sweep",
 "broke":"break","broken":"break","said":"say","made":"make","kept":"keep","let":"let",
 "hit":"hit","cut":"cut","put":"put","set":"set","sat":"sit","won":"win","lost":"lose",
 "drew":"draw","drawn":"draw","heads":"head","hands":"hand","backs":"back","ends":"end",
 "wore":"wear","worn":"wear","knew":"know","known":"know","woke":"wake","woken":"wake",
 "sped":"speed","told":"tell","meant":"mean","left":"leave","chose":"choose","chosen":"choose",
}

def first_word_matches(w, b):
    if w == b: return True
    if IRR.get(w) == b: return True
    if w == b + "s": return True
    if w == b + "es": return True
    if w == b + "ed": return True
    if w == b + "d": return True
    if w == b + "ing": return True
    if b.endswith("e") and w == b[:-1] + "ing": return True
    if len(b) >= 3 and w == b + b[-1] + "ed": return True     # stepped
    if len(b) >= 3 and w == b + b[-1] + "ing": return True    # stepping
    if b.endswith("y") and w == b[:-1] + "ied": return True   # carried
    if b.endswith("y") and w == b[:-1] + "ies": return True
    return False

def resolve_base(display, bases):
    dw = display.lower().split()
    for b in bases:
        bw = b.split()
        if len(dw) == len(bw) and dw[1:] == bw[1:] and first_word_matches(dw[0], bw[0]):
            return b
    return None

def norm_expr(s):
    return re.sub(r"[.!?]+$", "", s.lower()).strip()

text = open(MD).read()
sections = re.split(r"^## ", text, flags=re.M)[1:]
out = {}
errors = []
for sec in sections:
    header = sec.split("\n", 1)[0]
    m = re.match(r"([a-z0-9-]+-2026)", header)
    if not m:
        continue  # notes/corrections sections
    sid = m.group(1)
    body = sec.split("\n", 1)[1]
    lines = []
    for ln in body.split("\n"):
        lm = re.match(r"^(A|B): (.+)$", ln.strip())
        if lm:
            lines.append({"s": lm.group(1), "text": lm.group(2).strip()})
    if not lines:
        continue
    # cards from "Cards:" block: "- expr: def | "ex1" / "ex2""
    cards = []
    cm = re.search(r"^Cards:\n((?:- .+\n?)+)", body, flags=re.M)
    if cm:
        for row in cm.group(1).strip().split("\n"):
            rm = re.match(r'^- (.+?): (.+?) \| (.+)$', row.strip())
            if rm:
                exs = [e.strip().strip('"') for e in rm.group(3).split(' / ')]
                cards.append({"expr": rm.group(2) and rm.group(1), "def": rm.group(2), "ex": exs})
    if sid in EXTRA_CARDS and not cards:
        cards = [{"expr": e, "def": d, "ex": x} for e, d, x in EXTRA_CARDS[sid]]

    story = json.load(open(os.path.join(STORY_DIR, sid + ".json")))
    bases = [v["verb"].lower() for v in story.get("vocab", [])]
    verb_map = {}
    card_keys = {norm_expr(c["expr"]) for c in cards}
    used_keys = set()
    for l in lines:
        for d in re.findall(r"\{\{([^}]*)\}\}", l["text"]):
            base = resolve_base(d, bases)
            if not base:
                errors.append("%s: verb '%s' does not match any vocab base" % (sid, d))
            else:
                verb_map[d.lower()] = base
        for e in re.findall(r"\[\[([^\]]*)\]\]", l["text"]):
            k = norm_expr(e)
            used_keys.add(k)
            if k not in card_keys:
                errors.append("%s: expression '%s' has no card" % (sid, e))
    for c in cards:
        if norm_expr(c["expr"]) not in used_keys:
            errors.append("%s: card '%s' not used in text" % (sid, c["expr"]))
    # no em dashes anywhere
    for l in lines:
        if "—" in l["text"]:
            errors.append("%s: em dash in line: %s" % (sid, l["text"][:50]))
    out[sid] = {"lines": lines, "verbMap": verb_map, "expressions": cards}

if errors:
    print("ERRORS (%d):" % len(errors))
    for e in errors: print(" -", e)
    sys.exit(1)
json.dump(out, open(OUT, "w"), ensure_ascii=False, indent=1)
print("OK: %d dialogues -> %s" % (len(out), OUT))
for sid, d in out.items():
    print("  %-38s %2d lines, %2d verbs, %d expressions" % (sid, len(d["lines"]), len(d["verbMap"]), len(d["expressions"])))
