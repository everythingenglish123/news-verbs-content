# Dialogue section drafts (John's new feature, 29 Aug 2026)

- Two people talking about the news; goes AFTER the phrasal verbs/expressions section.
- Style approved: "Version A" for giraffe = short (~9-11 exchanges), natural, playful
  where the topic allows (serious topics keep a warm respectful register).
- Use the story's phrasal verbs in the SAME sense as the story; aim for all, ok to skip
  one or two when forcing sounds unnatural. B1 vocabulary. Audio-safe speaker names
  (Anna/Ben, Maya/Sam, Leo/Emma).
- Status: samples only, NOT in the app yet. Open questions for John: tappable verb
  highlighting, two-voice audio, translations in sidecars.

Drafted so far: giraffes-math-barcelona-2026 (APPROVED style), venezuela-earthquake-rescue-2026,
swift-kelce-wedding-charity-2026, italy-solar-railway-2026 (all in dialogues.md).

## Rules added by John, 29 Aug (v2 review):
- NO extra phrasal verbs beyond the story's taught verbs anywhere in a dialogue
  (same rule as quiz explanations). "drive over" was caught and removed.
- Expression cards: define the actual meaning/function, not the tone
  ("half of Hollywood" = exaggerating the amount, NOT "funny way to say famous people").
- Speakers A/B, no names, no em dashes.
