# Reserve articles (READY, NOT pushed)

## PUSHED 29 Aug 2026 (John: "Push number two, number three, and number four")

- **n86 robot-games-beijing-2026**, **n87 cia-moscow-visit-2026**,
  **n88 dolly-parton-dies-2026** are LIVE (published in that order, Dolly newest
  on top). Full pipeline each: dry-run + real publish (content_audit and
  fill_in_blank_audit ALL CLEAN across 77/78/79 stories), covers converted to
  1600x900 webp under images/, 12 audio clips uploaded with read-back verify and
  av restamp (c3c87982a9 / fc6cd82dc8 / 4af075c541), 60 translation sidecars
  uploaded under stories/ (translate_audit ALL CLEAN; sidecar numbers fixed
  95->86, 92->87, 94->88 before upload). All objects verified via boto3
  head_object/get_object. Live index: 79 entries, newest 88 dolly-parton-dies.
- Fixed during push: FB conjugation tables were missing speed->"sped"
  (robot story "sped up"). Added to FB_IRREG_PAST and FB_PARTICIPLE in the app
  HTML (container master) and to the IRR table in Tools/fill_in_blank_audit.js.
  The Mac app HTML copies (md5 ee6ce7bf65ae) predate this - resync + next app
  release must ship the newer HTML.
- Still unpushed from the six: talking-less-study-2026 (n89 next),
  australia-teen-ban-2026, nepal-flash-flood-2026 - fully produced, renumber at
  push time. Plus the 7 older reserves.
- Next free number: 89.

## PUSHED 23 Aug 2026 (John's out-of-order instruction)

- **n83 rage-bait-word-2026** and **n84 cancer-vaccine-melanoma-2026** are LIVE
  (published in that order, cancer newest on top). Full pipeline: covers, stories,
  index, 8 audio clips (av hashes stamped), 40 translation sidecars. Archived to
  news-verbs-content and pushed to GitHub (commit c087c6c).
- **Top-9 date reorder executed** in the same push: us-debt, social-media-trial,
  waymo, belgium-gold, dogs, colombia, sharks, walkable, video-game (now positions
  3-11 under the two new stories).
- Live feed is now 75 stories. Next free number: 85.
- Fixed during push: British spelling "cancelled"->"canceled" in
  china-rocket-recovery-2026 quiz explanation (live story re-uploaded).

## Queues (John's organization, 22 Aug 2026, updated 23 Aug)

**NEWS QUEUE - pushes FIRST, oldest first so the app ends date-ordered:**
1. electronic-skin-touch-2026 (Aug 10)
2. creator-earnings-study-2026 (Aug 19-20)

**TREND RESERVE - John's push order for emergencies/fillers:**
1. 2016-nostalgia-wave-2026
2. ai-slop-flood-2026
3. flash-panning-dating-2026
4. gen-z-stare-2026
5. job-hugging-trend-2026
6. aura-points-trend-2026

Stories written 22 Aug 2026 on John's instruction, then fully produced the same
day. When John says **push** (one or several), run the publish pipeline below for the
remaining 8. (n83 rage-bait and n84 cancer-vaccine are already live, see top.)

| # (working) | id | headline | badge |
|---|---|---|---|
| n83 | electronic-skin-touch-2026 | Electronic skin gives robots a sense of touch | Technology |
| n84 | creator-earnings-study-2026 | Study: most online creators earn less than you think | Culture |
| n85 | flash-panning-dating-2026 | Flash-panning: romance that starts hot and ends in silence | Culture |
| n86 | job-hugging-trend-2026 | Job hugging: why nobody wants to quit anymore | Culture |
| n87 | aura-points-trend-2026 | Aura points: the internet's new game of looking cool | Culture |
| n88 | ai-slop-flood-2026 | AI slop is flooding your feed, and it pays | Technology |
| n89 | rage-bait-word-2026 | Rage bait: the trick that turns your anger into money | Culture |
| n90 | gen-z-stare-2026 | The Gen Z stare: rude, honest, or just misunderstood? | Culture |
| n91 | 2016-nostalgia-wave-2026 | 2026 is the new 2016: the internet replays a decade | Culture |

## State of production (all DONE unless noted)

- **Text**: final after John's 22 Aug review (come near demoted to vocab; leave behind,
  speed up, leave out added; electric added; vocab lists expanded to 23-25). Validators:
  validate_story.py CLEAN x9, content_audit rules CLEAN, fill_in_blank_audit (real app
  renderer) ALL CLEAN on reserves AND on the live 73-story feed.
- **Videos**: 4th video source added to 8 stories. creator-earnings-study-2026 has NO
  video (no good match found); add one at push time if John wants.
- **App FB table**: start|on exclusion added to FB_HEAD_PARTICLES in all 6 app HTML
  copies (md5 7f2803ff9c6c) + container copy. (The earlier "stand|down" flag was an
  audit mis-attribution, now fixed in Tools/fill_in_blank_audit.js and the container copy:
  exact conjugated-form owner matching before the prefix heuristic.)
- **Covers**: 9 PNGs, GPT Image 2.0, 2048x1152, in `Story Creation/Reserve/Covers/`
  named `<id>-cover.png`. NOT uploaded. `position` values already set in each story
  JSON. John has seen a contact sheet; regenerate on request.
- **Audio**: 36 finals in `News Audio/<slug>/` (slug = id without -2026) and converted
  m4a (-16 LUFS, AAC 48k mono) in `News Audio (app m4a)/<slug>/`. John chose Take 1
  for the two multi-take paragraphs (electronic-skin-touch p1 "Hanyang",
  2016-nostalgia-wave p3 "Zara Larsson"). check_takes: 35/36 clean; rage-bait-word p3
  shows a KNOWN FALSE NEGATIVE: the voice says "two thousand AND two" for 2002, which
  is correct English, but the checker wants the literal "two thousand two". Clip
  verified by transcript. NOT pushed (push_audio_r2 not run, no av restamp).
  LOUDNESS VERIFIED 22 Aug: all 40 new m4a clips measured directly with ebur128 at
  -16.0 to -16.6 LUFS; sampled live-app clips measure -16.1 to -16.4. The batch matches
  the application's level.
- **Translations**: 180 sidecars (20 langs x 9) in container `/home/claude/pub/tr9/`
  and Mac `Story Creation/Reserve/tr9/` (+ tr9-reserve.tgz). Independently audited:
  keys English, byte-identical def==correct, gap<=10, wordDefs ex==2, vocab ex==3, no
  ipa, no em dashes. NOT uploaded.

## Push checklist (per story, when John says push)

1. `Tools/state_check.py`: renumber against the LIVE feed (numbers 83-91 are working
   placeholders). Update `number` and the `image` URL prefix `n{num}-`.
2. Cover: hand `Story Creation/Reserve/Covers/<id>-cover.png` to `publish.py --cover`
   (converts to 1600x900 webp, uploads, verifies).
3. Story: publish via publish.py in the container against a FRESH feed pulled from the
   Mac (never GitHub). fill_in_blank_audit must run as part of it.
4. Audio: `push_audio_r2.py "News Audio (app m4a)"` for the story's 4 clips (uploads,
   read-back verify, av restamp).
5. Translations: upload the story's 20 sidecars from `tr9/` (audit + head_object verify).
6. Archive story + sidecars into news-verbs-content and commit.
7. App release only if the FB-table change should reach installed apps before n84 ships
   (content pushes alone do not ship app HTML).

Copies of the 9 final JSONs also sit in `news-verbs-content/stories/` (needed there by
generate_audio.py). They are NOT in feed.json/index.json, so publishes cannot resurrect
them by accident.

## Quiz explanations v2 (collocation-first) - LIVE 23 Aug 2026

John replaced the v1 teacher-explanation style with a collocation-first style: sentence 1
gives 2-4 real collocations (or a usage pattern when none exist), sentence 2 re-anchors
the verb in the story's actual fact. Never restates the definition. Rules:
/home/claude/whyjob/GUIDE-v2.md (Mac: Story Creation/whyjob-GUIDE-v2.md). All 930
explanations rewritten (Sonnet drafts, Fable QC: 9 stray-phrasal-verb/accuracy fixes,
21 B1-vocabulary fixes), audits ALL CLEAN, all 75 live stories re-uploaded to R2 with
verification, reserve stories updated, git commit e825120. v1 texts archived in
whyjob/whys/ (container). Also fixed this session: 10 quiz answer options that contained
other phrasal verbs (plus matching vocab defs and 120 retranslated sidecars, commit
995cff3).

## Quiz explanations ("why" on every quiz verb) - v1 history, added 23 Aug 2026

John-approved teacher-voice explanation for every definition-quiz verb, shown after the
student answers. Format rules live in Story Creation/whyjob GUIDE (container:
/home/claude/whyjob/GUIDE.md): 1-2 sentences, no em dashes, no other phrasal verbs, no
caps emphasis, max one word-order tip and one other-meaning warning per story, adult
register, American framing.

- 930 explanations across all 83 stories (73 live + 10 waiting), written by Sonnet
  agents and QC'd by Fable (14 stray-phrasal-verb fixes applied, all checks clean).
- Merged into: news-verbs-content/stories/*.json, news-verbs-content/feed.json (the
  authoring master, so the next content publish ships them), and Story Creation/Reserve/.
- LIVE since 23 Aug (John approved): the 73 live stories/<id>.json on R2 now carry the
  why field (uploaded with read-back verification; no index change, no reorder, no new
  stories). Display code added to renderInteractiveArticle in all 6 app HTML copies
  (md5 dd7f356e7332) + container copy: after a definition-quiz answer, item.why renders
  as a p.actfeedback line, same styling as the true/false explanations. The local Web
  App file shows it now; installed mobile apps ignore the field until the next app
  release ships the new HTML.
- Sidecars deliberately untranslated for this field: the explanation always shows in
  English.
- Vocabulary pass 23 Aug (John's request): 37 explanations across 26 stories rewritten
  to remove B2+/rare defining words (radiate, persistently, discard, allegedly, ordeal,
  subtle, etc.). List: Story Creation/vocab_fixes-23aug.json. The 21 affected LIVE
  stories re-uploaded to R2 (verified); 5 reserve stories fixed in place. Synced to
  news-verbs-content/stories, feed.json, and Story Creation/Reserve.

## New drafts, 29 Aug 2026 (WRITTEN, AWAITING JOHN'S REVIEW)

Six stories John requested on 29 Aug, drafted and fully audited (validate_story CLEAN,
content_audit CLEAN, fill-in-the-blank candidate audit CLEAN, 71 questions checked):

| working # | id | headline | badge |
|---|---|---|---|
| n92 | cia-moscow-visit-2026 | America's top spy makes a quiet trip to Moscow | Geopolitics |
| n93 | nepal-flash-flood-2026 | Deadly floods hit the mountains of Nepal | World |
| n94 | dolly-parton-dies-2026 | Dolly Parton dies at age 80 | Entertainment |
| n95 | robot-games-beijing-2026 | A robot runs 100 meters faster than any human | Technology |
| n96 | australia-teen-ban-2026 | Australia banned teen social media. Did it work? | Technology |
| n97 | talking-less-study-2026 | People are talking less every year | Science |

- Files: container /home/claude/newstories/, Mac Story Creation/Reserve/new6-29aug/.
- NOT produced yet: no covers, no audio, no translations. Produce after John approves text.
- Each has a verified video source (oembed-checked): CBS (CIA, Dolly), Euronews (Nepal),
  BBC (robots), 9News (Australia), DW (talking-less, John's own pick).
- App FB tables extended for this batch (26 new syn pairs/groups, 7 head-particle rows:
  sweep/switch/play/sit/strike/plug/type). All 4 app HTML copies + container updated,
  md5 ee6ce7bf65ae. These table changes must ship in the next app release BEFORE any of
  these six go live.

## Scheduled pushes: FAILED (Mac unreachable at fire time)

- creator-earnings-study-2026: trigger fired 26 Aug 12:03 UTC, run FAILED, story NOT live.
- 2016-nostalgia-wave-2026: trigger fired 27 Aug 12:03 UTC, run FAILED, story NOT live.
- ai-slop-flood-2026: no successful run recorded; NOT live.
- Live feed still 76 stories as of 29 Aug. All 7 reserve stories remain unpushed; the
  three failed pushes need to be re-run manually when John says go.

## Production status update, 29 Aug 2026 (later session)

Everything for the six new stories is PRODUCED. NOT PUSHED.

- Text: John approved (CIA final sentence removed at his request; names Ratcliffe,
  Tianzhuo, Langtang stripped for audio safety). Frozen.
- Explanations: the 71-fix why audit (John approved via "keep going") is APPLIED:
  3 in these drafts, 7 in reserve stories, 37 live stories re-uploaded to R2 with
  byte verification, Mac feed/stories/reserve synced, git commit bcab777, pushed.
- Translations: 120 sidecars (6 x 20 langs), translate_audit ALL CLEAN.
  Container /home/claude/pub/tr6/flat, NOT on the Mac yet, NOT uploaded.
- Audio: 24 clips generated (best_take used on the 4 decimal paragraphs; the two
  check_takes FAILs are the known "two thousand AND five/nine" false negative),
  converted to m4a at -16 LUFS (spread 0.65 LU). In News Audio/ and
  News Audio (app m4a)/ on the Mac. Six new pronunciations added to
  Tools/pronunciations.json (both sides): Usain, Petersburg, Dollywood, Parton,
  Snapchat, TikTok. NOT pushed to R2 (no av restamp yet).
- Covers: 6 PNGs, GPT Image 2.0, 2048x1152, in Story Creation/Reserve/new6-29aug/Covers/
  named <id>-cover.png. Contact sheet shown to John. position values set in the drafts.
  NOT uploaded.
- Push order John set (oldest first): talking-less-study, robot-games-beijing,
  cia-moscow-visit, dolly-parton-dies, australia-teen-ban, nepal-flash-flood.
  Push planned for ~30 Aug. Remember: renumber against the LIVE feed at push time,
  and the FB-table app HTML change (md5 ee6ce7bf65ae) must ship in the next app release.
- Scratch files that can be deleted after push: Story Creation/_prodkit.tgz,
  Story Creation/new6_audio.tgz, Story Creation/why_fixes_29aug.json,
  Downloads/generated_1*.png.
