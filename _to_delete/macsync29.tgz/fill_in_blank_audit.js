const { chromium } = require("/home/claude/.npm-global/lib/node_modules/playwright");
const fs = require("fs");

const feed = JSON.parse(fs.readFileSync("/tmp/newsverbs/feed_new.json", "utf8"));
const stories = feed.stories || feed;

(async () => {
  const browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium-1194/chrome-linux/chrome" });
  const page = await browser.newPage();
  const errs = [];
  page.on("pageerror", e => errs.push("PAGEERROR: " + String(e).slice(0, 200)));
  await page.goto("file:///tmp/newsverbs/phrasal-verb-news.html", { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(800);

  const data = await page.evaluate((sts) => {
    // deterministic shuffle so the audit is reproducible
    window.shuffle = function(arr) { return arr.slice(); };
    const out = [];
    sts.forEach(story => {
      const div = document.createElement("div");
      renderFillBlank(div, story);
      const boxes = [...div.querySelectorAll(".actbox")].map(box => {
        const q = box.querySelector(".actq").textContent;
        const rows = [...box.querySelectorAll("div")].filter(d => d.querySelector && d.querySelector(".quizbtn") && d.style.display === "flex");
        if (rows.length) {
          return { q, multi: true,
            rows: rows.map(r => [...r.querySelectorAll(".quizbtn")].map(b => b.textContent)),
            correct: rows.map(r => { const c = r.querySelector(".quizbtn[data-correct]"); return c ? c.textContent : null; }) };
        }
        const btns = [...box.querySelectorAll(".quizbtn")];
        const c = box.querySelector(".quizbtn[data-correct]");
        return { q, multi: false, options: btns.map(b => b.textContent), correct: [c ? c.textContent : null] };
      });
      out.push({ id: story.id, boxes });
    });
    return out;
  }, stories);

  // The audit reads the particle tables OUT OF THE APP, so the gate and the generator
  // can never drift apart. If the app's list changes, this check changes with it.
  const ptab = await page.evaluate(() => ({
    particles: (typeof FB_PARTICLES !== "undefined") ? FB_PARTICLES : null,
    opposite: (typeof FB_OPPOSITE !== "undefined") ? FB_OPPOSITE : null,
    heads: (typeof FB_HEAD_PARTICLES !== "undefined") ? FB_HEAD_PARTICLES : null
  }));
  if (!ptab.particles || !ptab.opposite || !ptab.heads) {
    console.log("FAIL: the app is missing FB_PARTICLES / FB_OPPOSITE / FB_HEAD_PARTICLES");
    await browser.close(); process.exit(1);
  }
  const PARTICLES = new Set(ptab.particles);
  const OPPOSITE = ptab.opposite;
  const HEAD_PARTICLES = ptab.heads;
  let particleTotal = 0;

  // ---------- validations (node side) ----------
  const problems = [];
  const MALFORMED = /\b(hited|hitted|comed|goed|gos|dos|taked|breaked|bringed|catched|cutted|dealed|digged|falled|finded|gived|holded|keeped|knowed|leaved|losed|maked|meeted|paied|putted|runned|saied|sayed|selled|sended|setted|shooted|shutted|sitted|speaked|standed|sticked|teached|telled|thinked|throwed|weared|winned|letted|layed|riseed|writed|becomed)\b/i;
  const ABBR_END = /(?:\b[A-Z]\.){1,4}\s*$/;

  // build legit-form table per story: base -> all valid forms
  function heads(base) {
    const IRR = {speed:"sped",tear:"tore",buy:"bought",find:"found",take:"took",keep:"kept",tell:"told",set:"set",go:"went",come:"came",give:"gave",make:"made",hold:"held",stand:"stood",break:"broke",bring:"brought",catch:"caught",build:"built",get:"got",put:"put",run:"ran",cut:"cut",deal:"dealt",dig:"dug",lose:"lost",meet:"met",sell:"sold",send:"sent",sit:"sat",speak:"spoke",spend:"spent",teach:"taught",think:"thought",throw:"threw",fall:"fell",feed:"fed",grow:"grew",hear:"heard",lead:"led",leave:"left",let:"let",pay:"paid",draw:"drew",shut:"shut",win:"won",fly:"flew",fight:"fought",read:"read",say:"said",wear:"wore",hit:"hit",shoot:"shot",stick:"stuck",lay:"laid",become:"became",feel:"felt",mean:"meant",rise:"rose",see:"saw",know:"knew",write:"wrote",do:"did",eat:"ate",begin:"began",hang:"hung",hurt:"hurt",cost:"cost",beat:"beat",bet:"bet",spread:"spread",quit:"quit",light:"lit",strike:"struck",spring:"sprang",wind:"wound",drive:"drove",ride:"rode",choose:"chose",forget:"forgot",freeze:"froze",wake:"woke",steal:"stole",shake:"shook",sing:"sang",sink:"sank",swim:"swam",ring:"rang",blow:"blew",bend:"bent",bite:"bit",hide:"hid",understand:"understood",seek:"sought",sweep:"swept",sleep:"slept",slide:"slid"};
    const PART = {tear:"torn",buy:"bought",take:"taken",give:"given",go:"gone",break:"broken",come:"come",run:"run",draw:"drawn",fall:"fallen",fly:"flown",grow:"grown",throw:"thrown",speak:"spoken",wear:"worn",write:"written",do:"done",see:"seen",eat:"eaten",know:"known",begin:"begun",show:"shown",get:"gotten",spring:"sprung",wind:"wound",drive:"driven",ride:"ridden",rise:"risen",hide:"hidden",choose:"chosen",forget:"forgotten",freeze:"frozen",steal:"stolen",shake:"shaken",sing:"sung",sink:"sunk",swim:"swum",ring:"rung",blow:"blown",wake:"woken",beat:"beaten",bite:"bitten"};
    const h = base.split(" ")[0].toLowerCase(), rest = base.split(" ").slice(1).join(" ");
    const past = IRR[h] || (/e$/.test(h) ? h + "d" : /[^aeiou]y$/.test(h) ? h.slice(0, -1) + "ied" : /^[^aeiou]*[aeiou][^aeiouwxy]$/.test(h) ? h + h.slice(-1) + "ed" : h + "ed");
    const part = PART[h] || past;
    const s = /[^aeiou]y$/.test(h) ? h.slice(0, -1) + "ies" : /(s|x|z|ch|sh|o)$/.test(h) ? h + "es" : h + "s";
    const ing = /ie$/.test(h) ? h.slice(0, -2) + "ying" : (/e$/.test(h) && !/(ee|ye|oe)$/.test(h)) ? h.slice(0, -1) + "ing" : /^[^aeiou]*[aeiou][^aeiouwxy]$/.test(h) ? h + h.slice(-1) + "ing" : h + "ing";
    const mk = x => (x + " " + rest).trim();
    return { base: mk(h), s: mk(s), ing: mk(ing), past: mk(past), part: mk(part) };
  }
  function catsOf(opt, bases) {
    // A form can be ambiguous ("set off" is base AND past) -> return the set of possible categories
    const cats = new Set();
    for (const b of bases) {
      const f = heads(b);
      if (opt === f.base) cats.add("base");
      if (opt === f.s) cats.add("s");
      if (opt === f.ing) cats.add("ing");
      if (opt === f.past || opt === f.part) cats.add("past");
    }
    return cats; // empty = not a legitimate form of any story verb
  }

  // synonym groups — must stay in sync with FB_SYN_GROUPS in the app. Two options that
  // map to bases in the same group means the question has more than one correct answer.
  const FB_SYN_GROUPS = [
    ["step down", "stand down", "hand in", "back down", "pull out", "give up"],
    ["go up", "shoot up"],
    ["cut down", "cut down on"],
    ["cool down", "cool off", "let up"],
    ["give back", "hand over", "hand back", "bring back"],
    ["look into", "look over", "go over"],
    ["figure out", "work out", "find out"],
    ["turn up", "show up"],
    ["team up", "team up with"],
    ["end up", "turn out"],
    ["dig out", "pull out", "dig up"],
    ["go ahead", "carry on"],
    ["get rid of", "throw away", "take away"],
    ["catch on", "take off"]
  ];
  const FB_SYN = {};
  FB_SYN_GROUPS.forEach(grp => grp.forEach(a => {
    FB_SYN[a] = FB_SYN[a] || new Set();
    grp.forEach(b => { if (b !== a) FB_SYN[a].add(b); });
  }));
  const areSyn = (a, b) => !!(FB_SYN[a.toLowerCase()] && FB_SYN[a.toLowerCase()].has(b.toLowerCase()));
  // map a displayed (conjugated) option back to its base within a story
  function optToBase(opt, bases) {
    for (const b of bases) {
      const f = heads(b);
      if (opt === f.base || opt === f.s || opt === f.ing || opt === f.past || opt === f.part) return b.toLowerCase();
    }
    return null;
  }

  let boxesTotal = 0, multiTotal = 0;
  data.forEach(st => {
    const story = stories.find(s => s.id === st.id);
    const bases = [...new Set(story.chunks.flatMap(c => c.verbs.map(v => v.base)))];
    st.boxes.forEach((box, bi) => {
      boxesTotal++;
      const tag = `${st.id} box#${bi}`;
      if (MALFORMED.test(box.q)) problems.push(`${tag}: malformed word in question: ${box.q.slice(0, 60)}`);
      if (!box.q.includes("______")) problems.push(`${tag}: no blank in question`);
      if (ABBR_END.test(box.q.trim())) problems.push(`${tag}: question ends mid-sentence at abbreviation: ...${box.q.slice(-30)}`);
      const groups = box.multi ? box.rows : [box.options];
      if (box.multi) {
        multiTotal++;
        const flat = box.rows.map(r => r.slice().sort().join("|"));
        if (new Set(flat).size !== flat.length) problems.push(`${tag}: two rows have IDENTICAL option pairs`);
        const all = box.rows.flat();
        if (new Set(all).size !== all.length) problems.push(`${tag}: same option appears in more than one row: ${all.join(", ")}`);
        box.rows.forEach((r, ri) => { if (r.length < 2) problems.push(`${tag} row${ri + 1}: only ${r.length} option(s)`); });
      } else {
        if (box.options.length < 2) problems.push(`${tag}: only ${box.options.length} option(s)`);
      }
      groups.forEach((opts, gi) => {
        // ---- particle questions -------------------------------------------------
        // Half the single-blank items hide the particle, not the verb, so every option
        // is a bare particle. Those are validated on their OWN terms: the conjugation
        // and synonym machinery below does not apply and would only produce noise.
        if (opts.length && opts.every(o => PARTICLES.has(o))) {
          particleTotal++;
          const correctP = box.correct[gi];
          if (!correctP) problems.push(`${tag} g${gi}: particle question with no correct option`);
          if (new Set(opts).size !== opts.length) problems.push(`${tag} g${gi}: duplicate particles ${JSON.stringify(opts)}`);
          // Which verb is this blank for? The word right before the blank is the
          // conjugated head, so map it back to one of the story's own base verbs.
          const m = box.q.match(/(\S+)\s+______/);
          const headWord = m ? m[1].toLowerCase().replace(/[^a-z]/g, "") : "";
          const exact = bases.find(b => {
            const f = heads(b);
            return [f.base, f.s, f.ing, f.past, f.part].some(x => x.split(" ")[0] === headWord);
          });
          const owner = exact || bases.find(b => {
            const h = b.split(" ")[0].toLowerCase();
            return headWord === h || headWord.startsWith(h.slice(0, Math.max(3, h.length - 2)));
          });
          const head = owner ? owner.split(" ")[0].toLowerCase() : null;
          opts.forEach(o => {
            if (o === correctP) return;
            if (OPPOSITE[correctP] === o || OPPOSITE[o] === correctP)
              problems.push(`${tag} g${gi}: "${o}" is the opposite of "${correctP}", both read as English`);
            if (head && HEAD_PARTICLES[head] && HEAD_PARTICLES[head].includes(o))
              problems.push(`${tag} g${gi}: "${head} ${o}" is a real phrasal verb, so "${o}" is a defensible second answer`);
          });
          return;
        }
        const catSets = opts.map(o => catsOf(o, bases));
        catSets.forEach((c, i) => { if (c.size === 0) problems.push(`${tag} g${gi}: unrecognized/malformed form "${opts[i]}"`); });
        // consistent if ONE category exists that every option could be
        const nonEmpty = catSets.filter(c => c.size > 0);
        if (nonEmpty.length === opts.length && opts.length > 1) {
          const shared = [...nonEmpty[0]].filter(c => nonEmpty.every(s => s.has(c)));
          if (shared.length === 0) problems.push(`${tag} g${gi}: MIXED TENSES ${JSON.stringify(opts)} -> ${catSets.map(s => [...s].join("/")).join(", ")}`);
        }
        opts.forEach(o => { if (MALFORMED.test(o)) problems.push(`${tag} g${gi}: malformed option "${o}"`); });
        if (new Set(opts).size !== opts.length) problems.push(`${tag} g${gi}: duplicate options ${JSON.stringify(opts)}`);
        // MORE-THAN-ONE-CORRECT-ANSWER check: a distractor must not be a synonym of the
        // correct answer for THIS blank (that would make it a second valid answer).
        const correctOpt = box.correct[gi];
        const correctBase = correctOpt ? optToBase(correctOpt, bases) : null;
        if (correctBase) {
          opts.forEach((o, i) => {
            if (o === correctOpt) return;
            const ob = optToBase(o, bases);
            if (ob && areSyn(ob, correctBase)) {
              problems.push(`${tag} g${gi}: TWO CORRECT ANSWERS — distractor "${o}" (${ob}) is a synonym of the answer "${correctOpt}" (${correctBase})`);
            }
          });
        }
      });
    });
  });

  console.log(`stories audited: ${data.length}  question boxes: ${boxesTotal}  (multi-blank: ${multiTotal})`);
  console.log(`pageerrors: ${errs.length} ${errs.join(" | ")}`);
  if (problems.length) { console.log(`PROBLEMS (${problems.length}):`); problems.forEach(p => console.log("  - " + p)); }
  else console.log("ALL CLEAN — no malformed forms, no tense mixing, no fragments, no repeated pairs.");
  await browser.close();
  process.exit(problems.length || errs.length ? 1 : 0);
})();
